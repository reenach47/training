package javatraining;
class name{
	protected void display() {
		System.out.println("hie");
	}
	
}

public class protectedmodifier extends name {

	public static void main(String[] args) {
		 protectedmodifier obj=new  protectedmodifier();
		 obj.display();
	}
}
