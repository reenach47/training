package javatraining;
class b{
	void m1() {
		System.out.println("hello");
	}
}


	


