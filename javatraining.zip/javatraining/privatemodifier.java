package javatraining;
class a{
	private int data=4;
	void m1() {
		System.out.println("hello");
	}	
}
public class privatemodifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        a obj=new a();
    	System.out.println("hi");
    	obj.m1();
        
	}

}
