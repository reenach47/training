package javatraining;

public class ArithmeticException extends Exception {

	public ArithmeticException(String string) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
