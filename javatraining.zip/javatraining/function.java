package javatraining;


public class function {
	
			public static void main(String[] args) {
				System.out.println("Default main");
				main(15);
				main(9);
     }
			

}
