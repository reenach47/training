package javatraining;

public class Defaultcontructor {

	public static void main(String[] args) {
		int num; 
		float b; 
		char c; 
		String s; 
		byte by;
		double d;
		short sh;
		boolean bn;
		long l;
		num = 100;
		b =1.234f;
		c ='A'; 
		s = "Hie"; 
		by =0;
		d =12;
		sh =0;
		bn=false;
		l=9l;

		System.out.println("Value of num: "+num);
		System.out.println("Value of b: "+b);
		System.out.println("Value of c: "+c);
		System.out.println("Value of s: "+s); 
		System.out.println("Value of by: "+by);
		System.out.println("Value of d: "+d);
		System.out.println("Value of sh: "+sh);
		System.out.println("Value of bn: "+bn);
		System.out.println("Value of l: "+l);
	} 

	}

