package javatraining;

public class Constructmain {
        int num; 
		float b; 
		char c; 
		String s; 
		byte by;
		double d;
		short sh;
		boolean bn;
		long l;
	public static void main(String[] args) {
		Constructmain obj=new Constructmain();
		System.out.println("default value:");
		System.out.println("num=" +obj.num);
		System.out.println("b=" +obj.b);
		System.out.println("c=" +obj.c);
		System.out.println("by=" +obj.by);
		System.out.println("d=" +obj.d);
		System.out.println("sh=" +obj.sh);
		System.out.println("bn=" +obj.bn);
		System.out.println("l=" +obj.l);
		
		

	}

}
