package javatraining;

public class trycatch {

	public static void main(String[] args) {
		try 
		{
			int x=10/1;
		}
		catch(trycatch e) 
		{
		System.out.println("Exception handle");
		}
	}
}
