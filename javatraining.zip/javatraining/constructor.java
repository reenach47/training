package javatraining;

public class constructor {
         String name;
		 int id;
		 int sal;
		 String desg;
	    public static void main(String[] args) {
	    	 constructor emp1=new constructor("reena",12,14000,"trainee");
	    	 emp1.display();
	    	 		
	    	 

	}

}
